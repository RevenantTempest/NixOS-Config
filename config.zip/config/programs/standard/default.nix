{ ... }:
{
  imports = [
    ./applications.nix
  ];
}
