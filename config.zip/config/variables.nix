{ inputs, nixpkgs, nixpkgs-unstable }:

rec {
  # System
  sys = {
    system = "x86_64-linux";
    stateVersion = "25.11";
    channel = "nixos-25.11";
  };

  # User
  user = {
    name = "nate";
    home = "/home/${user.name}";
  };

  # Git & Backup
  git = {
    username = "RevenantTempest";
    email = "nathanielh030@gmail.com";
    repoName = "NixOS-Config";
  };

  # Paths
  paths = {
    config = "${user.home}/nixos-config/config";
    backup = "${user.home}/nixos-config";
  };

  # LabWC
  labwcFiles = "${paths.config}/system/labwc/files";

  # Shell Aliases
  aliases = {
    rebuild = "sudo nixos-rebuild switch --flake path:${paths.config}#nixos";
  };

  # App Flags
  flags = {
    chrome = [
      "--force-device-scale-factor=1.25"
      "--enable-features=VaapiVideoDecodeLinuxGL,VaapiVideoEncoder,Vulkan,VulkanFromANGLE,DefaultANGLEVulkan,VaapiIgnoreDriverChecks,VaapiVideoDecoder,PlatformHEVCDecoderSupport,UseMultiPlaneFormatForHardwareVideo"
      "--ozone-platform-hint=wayland"
    ];
  };

  # Package Sets
  pkgs = import nixpkgs {
    system = sys.system;
    config.allowUnfree = true;
  };

  pkgs-unstable = import nixpkgs-unstable {
    system = sys.system;
    config.allowUnfree = true;
  };
}
