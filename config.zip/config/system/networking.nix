{ ... }:

{
  networking.networkmanager.enable = true;
}
